package splitminer;
public class Edge{

   Character tarjet;
   int freq;
   
   public Edge(Character t, int f){
   this.tarjet = t;
   this.freq = f; 
   }
   
}
